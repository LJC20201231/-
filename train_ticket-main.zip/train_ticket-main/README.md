

# 火车票预订系统

一个基于微服务架构的火车票在线预订系统，采用 Spring Cloud 技术栈构建。

## 项目简介

该项目是一个完整的火车票预订管理平台，提供列车查询、余票查询、订单确认、会员管理等核心功能。系统采用微服务架构，包含多个独立的服务模块，支持高并发场景下的票务处理。

## 技术栈

- **后端框架**: Spring Boot、Spring Cloud
- **服务网关**: Spring Cloud Gateway
- **服务注册与配置**: Nacos
- **数据库**: MyBatis、MySQL
- **缓存**: Redis
- **消息队列**: RocketMQ
- **分布式事务**: Seata
- **流量控制**: Sentinel
- **定时任务**: Quartz
- **远程调用**: Feign

## 模块介绍

### business（业务服务）
核心业务模块，包含：
- 列车管理（Train）
- 车站管理（Station）
- 车厢管理（TrainCarriage）
- 座位管理（TrainSeat）
- 每日列车计划（DailyTrain）
- 每日车站（DailyTrainStation）
- 每日座位（DailyTrainSeat）
- 每日车票（DailyTrainTicket）
- 订单确认（ConfirmOrder）
- 秒杀令牌（SkToken）

### member（会员服务）
会员管理模块，提供：
- 会员注册登录
- 乘车人管理
- 车票查询

### batch（调度服务）
定时任务服务，负责：
- 每日列车数据生成
- 定时调度任务管理

### gateway（网关服务）
API 网关，提供：
- 统一路由
- 登录拦截
- JWT 认证

### common（公共模块）
公共组件，包含：
- 统一响应格式
- 全局异常处理
- JWT 工具类
- 登录上下文
- 日志拦截器

### generator（代码生成器）
基于 Freemarker 的代码生成工具，快速生成 CRUD 代码。

## 核心业务流程

1. **列车数据管理**: 管理员维护基础列车、车站、车厢、座位数据
2. **每日计划生成**: 调度服务每日自动生成列车运行计划
3. **余票查询**: 用户查询特定日期、起始站的余票情况
4. **秒杀令牌**: 高并发场景下使用令牌桶机制控制流量
5. **订单确认**: 用户提交订单，系统自动分配座位
6. **出票**: 订单确认成功后生成车票

## 快速开始

### 环境要求

- JDK 1.8+
- Maven 3.6+
- MySQL 5.7+
- Redis
- Nacos
- RocketMQ

### 配置文件

各模块需要配置 `bootstrap.properties` 和 `application.properties`，主要配置项包括：

```properties
# 数据库配置
spring.datasource.url=jdbc:mysql://localhost:3306/train
spring.datasource.username=root
spring.datasource.password=your_password

# Redis配置
spring.redis.host=localhost
spring.redis.port=6379

# Nacos配置
spring.cloud.nacos.discovery.server-addr=127.0.0.1:8848
spring.cloud.nacos.config.server-addr=127.0.0.1:8848
```

### 启动顺序

1. 启动 Nacos 服务注册中心
2. 启动 MySQL 并执行 SQL 脚本（`sql/` 目录）
3. 启动 Redis 缓存服务
4. 启动 RocketMQ 消息队列
5. 依次启动各微服务模块

### 构建项目

```bash
mvn clean package -DskipTests
```

## API 文档

主要接口包括：

### 车站管理
- `GET /station/query-all` - 获取所有车站列表

### 列车管理
- `GET /train/query-all` - 获取所有列车列表
- `POST /admin/train/save` - 保存列车信息
- `GET /admin/train/gen-seat/{trainCode}` - 生成列车座位

### 每日列车
- `GET /admin/daily-train/query-list` - 查询每日列车
- `GET /admin/daily-train/gen-daily/{date}` - 生成指定日期的列车数据

### 车票查询
- `GET /daily-train-ticket/query-list` - 查询余票信息

### 订单确认
- `POST /confirm-order/do` - 提交订单确认

### 会员管理
- `POST /member/register` - 会员注册
- `POST /member/send-code` - 发送验证码
- `POST /member/login` - 会员登录

### 乘车人管理
- `POST /passenger/save` - 保存乘车人
- `GET /passenger/query-mine` - 查询我的乘车人

## 项目结构

```
train_ticket/
├── batch/              # 调度服务
├── business/           # 核心业务服务
├── common/             # 公共模块
├── gateway/            # 网关服务
├── generator/          # 代码生成器
├── member/             # 会员服务
├── sql/                # 数据库脚本
└── test/               # 接口测试文件
```

## 许可证

本项目仅供学习交流使用。