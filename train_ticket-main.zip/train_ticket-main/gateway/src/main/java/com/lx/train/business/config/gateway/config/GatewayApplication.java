package com.lx.train.business.config.gateway.config;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.core.env.Environment;

import java.util.logging.Logger;

@SpringBootApplication
@ComponentScan("com.lx")
public class GatewayApplication {
    private static Logger log = Logger.getLogger(String.valueOf(GatewayApplication.class));
    public static void main(String[] args) {
        // 只启动一次应用
        Environment env = SpringApplication.run(GatewayApplication.class, args).getEnvironment();

        log.info("项目启动成功!!!");
        // 修复URL格式和端口获取
        log.info("网关地址: \thttp://127.0.0.1:" + env.getProperty("server.port"));
    }

}
