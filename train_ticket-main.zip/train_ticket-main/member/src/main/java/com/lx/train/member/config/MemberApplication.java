package com.lx.train.member.config;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.core.env.Environment;

import java.util.logging.Logger;

@SpringBootApplication
@ComponentScan("com.lx")
@MapperScan("com.lx.train.member.mapper")
public class MemberApplication {
    private static Logger log = Logger.getLogger(String.valueOf(MemberApplication.class));
    public static void main(String[] args) {
        // 只启动一次应用
        Environment env = SpringApplication.run(MemberApplication.class, args).getEnvironment();

        log.info("项目启动成功!!!");
        // 修复URL格式和端口获取
        log.info("地址: \thttp://127.0.0.1:" + env.getProperty("server.port"));
    }

}
