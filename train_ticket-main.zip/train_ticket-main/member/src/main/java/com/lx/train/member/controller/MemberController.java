 package com.lx.train.member.controller;

 import com.lx.train.common.resp.CommonResp;
 import com.lx.train.member.req.MemberLoginReq;
 import com.lx.train.member.req.MemberRegisterReq;
 import com.lx.train.member.req.MemberSendCodeReq;
 import com.lx.train.member.resp.MemberLoginResp;
 import com.lx.train.member.service.MemberService;
 import jakarta.validation.Valid;
 import org.springframework.beans.factory.annotation.Autowired;
 import org.springframework.web.bind.annotation.*;

 @RestController
@RequestMapping("/member")
public class MemberController {
    @Autowired
    private MemberService memberService;

    @GetMapping("/count")
    public CommonResp test() {
        int count = memberService.count();
        CommonResp commonResp = new CommonResp();
        commonResp.setContent(count);
        return commonResp;
    }

    @PostMapping("/register")
    public CommonResp<Long> register(@Valid MemberRegisterReq req) {
        long register = memberService.register(req);
//        CommonResp<Long> commonResp = new CommonResp();
//        commonResp.setContent(register);
//        return commonResp;
        return new CommonResp<>(register);
    }

     /**
      * 发送短信接口
      * @param req
      * @return
      */
     @PostMapping("/send-code")
     public CommonResp<Long> sendCode(@Valid @RequestBody MemberSendCodeReq req) {
         memberService.sendCode(req);
         return new CommonResp<>();
     }

     /**
      * 登录接口
      * @param req
      * @return
      */
     @PostMapping("/login")
     public CommonResp<MemberLoginResp> sendCode(@Valid @RequestBody MemberLoginReq req) {
         return new CommonResp<>(memberService.login(req));
     }
}
