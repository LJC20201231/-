package com.lx.train.member.service;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.RandomUtil;
import com.lx.train.common.exception.BusinessException;
import com.lx.train.common.exception.BusinessExceptionEnum;
import com.lx.train.common.util.JwtUtil;
import com.lx.train.common.util.SnowUtil;
import com.lx.train.member.domain.Member;
import com.lx.train.member.domain.MemberExample;
import com.lx.train.member.mapper.MemberMapper;
import com.lx.train.member.req.MemberLoginReq;
import com.lx.train.member.req.MemberRegisterReq;
import com.lx.train.member.req.MemberSendCodeReq;
import com.lx.train.member.resp.MemberLoginResp;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MemberService {
    private static final Logger log = LoggerFactory.getLogger(MemberService.class);
    @Autowired
    private MemberMapper memberMapper;

    public int count() {
        return (int) memberMapper.countByExample(null);
    }

    public long register(MemberRegisterReq req){
        String mobile = req.getMobile();
        Member memberDB = selectByMobile(mobile);
        if(memberDB != null){
            //return members.get(0).getId();
            throw new BusinessException(BusinessExceptionEnum.MEMBER_MOBILE_EXIST);
        }
        Member member = new Member();
        member.setId(SnowUtil.getSnowflakeNextId());
        member.setMobile(mobile);
        memberMapper.insertSelective(member);
        return member.getId();
    }

    /**
     * 发送验证码
     * @param req
     * @return
     */
    public void sendCode(MemberSendCodeReq req){
        String mobile = req.getMobile();
        Member memberDB = selectByMobile(mobile);
        //如果手机号不存在,则插入一条记录
        if(memberDB == null){
            log.info("如果手机号不存在,则插入一条记录");
            Member member = new Member();
            member.setId(SnowUtil.getSnowflakeNextId());
            member.setMobile(mobile);
            memberMapper.insertSelective(member);
        }else{
            log.info("手机号存在,记录不插入");
        }
        //生成验证码
        String code = RandomUtil.randomString(4);
        log.info("生成短信验证码:{}" ,code);
        //保持短信记录表:手机号 短信验证码 有效期 是否已使用 业务类型 发送时间
        log.info("保存短信记录表");
        //对接短信通道 发送短信
        log.info("对接短信通道");
    }

    /**
     * 登录操作
     * @param req
     * @return
     */
    public MemberLoginResp login(MemberLoginReq req){
        String mobile = req.getMobile();
        String code = req.getCode();
        Member memberDB = selectByMobile(mobile);
        //如果手机号不存在,则抛出异常
        if(memberDB == null){
            //抛出异常
            throw new BusinessException(BusinessExceptionEnum.MEMBER_MOBILE_NOT_EXIST);
        }
        //校验短信验证码是否正确
        if(!code.equals("1234")){
            //抛出验证码错误的异常
            throw new BusinessException(BusinessExceptionEnum.MEMBER_CODE_ERROR);
        }
        //手机号已存在且验证码正确,返回会员信息
        MemberLoginResp resp = BeanUtil.copyProperties(memberDB, MemberLoginResp.class);
        String token = JwtUtil.createToken(resp.getId() , resp.getMobile());
        resp.setToken(token);
        return resp;
    }

    private Member selectByMobile(String mobile) {
        MemberExample memberExample = new MemberExample();
        memberExample.createCriteria().andMobileEqualTo(mobile);
        List<Member> members = memberMapper.selectByExample(memberExample);
        if(CollUtil.isEmpty(members)){
            return null;
        }else{
            return members.get(0);
        }
    }
}
