package com.lx.train.member.mapper;

import com.lx.train.member.domain.Member;
import com.lx.train.member.domain.MemberExample;
import java.util.List;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

public interface MemberMapper {
    long countByExample(MemberExample example);

    int deleteByExample(MemberExample example);

    @Delete({
        "delete from member",
        "where id = #{id,jdbcType=BIGINT}"
    })
    int deleteByPrimaryKey(Long id);

    @Insert({
        "insert into member (id, mobile)",
        "values (#{id,jdbcType=BIGINT}, #{mobile,jdbcType=VARCHAR})"
    })
    int insert(Member record);

    int insertSelective(Member record);

    List<Member> selectByExample(MemberExample example);

    @Select({
        "select",
        "id, mobile",
        "from member",
        "where id = #{id,jdbcType=BIGINT}"
    })
    @ResultMap("com.lx.train.member.mapper.MemberMapper.BaseResultMap")
    Member selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") Member record, @Param("example") MemberExample example);

    int updateByExample(@Param("record") Member record, @Param("example") MemberExample example);

    int updateByPrimaryKeySelective(Member record);

    @Update({
        "update member",
        "set mobile = #{mobile,jdbcType=VARCHAR}",
        "where id = #{id,jdbcType=BIGINT}"
    })
    int updateByPrimaryKey(Member record);
}