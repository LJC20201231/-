package com.lx.train.member.controller;

import com.lx.train.common.context.LoginMemberContext;
import com.lx.train.common.resp.CommonResp;
import com.lx.train.common.resp.PageResp;
import com.lx.train.member.req.PassengerQueryReq;
import com.lx.train.member.req.PassengerSaveReq;
import com.lx.train.member.resp.PassengerQueryResp;
import com.lx.train.member.service.PassengerService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/passenger")
public class PassengerController {
    @Autowired
    private PassengerService passengerService;

     /**
      * 新增乘客接口
      * @param req
      * @return
      */
    @PostMapping("/save")
    public CommonResp<Object> save(@Valid @RequestBody PassengerSaveReq req) {
        passengerService.savePassenger(req);
        return new CommonResp<>();
    }

     /**
      * 乘客查询接口
      * @param req
      * @return
      */
     @GetMapping("/query-list")
     public CommonResp<PageResp<PassengerQueryResp>> queryList(@Valid PassengerQueryReq req) {
         req.setMemberId(LoginMemberContext.getId());
         PageResp<PassengerQueryResp> list = passengerService.queryList(req);
         return new CommonResp<>(list);
     }

    /**
     * 删除乘客
     * @param id
     * @return
     */
     @DeleteMapping("/delete/{id}")
     public CommonResp<Object> delete(@PathVariable Long id) {
         passengerService.delete(id);
         return new CommonResp<>();
     }

    /**
     * 查询该会员的所有乘客接口
     * @return
     */
     @GetMapping("/query-mine")
    public CommonResp<List<PassengerQueryResp>> queryMine(){
         return new CommonResp<>(passengerService.queryMine());
     }
}
