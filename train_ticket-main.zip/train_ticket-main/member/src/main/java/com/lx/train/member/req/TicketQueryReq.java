package com.lx.train.member.req;

import com.lx.train.common.req.PageReq;
import lombok.Data;

@Data
public class TicketQueryReq extends PageReq {
    private Long memberId;
}
