package com.lx.train.member.mapper;

import com.lx.train.member.domain.Passenger;
import com.lx.train.member.domain.PassengerExample;
import java.util.List;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

public interface PassengerMapper {
    long countByExample(PassengerExample example);

    int deleteByExample(PassengerExample example);

    @Delete({
        "delete from passenger",
        "where id = #{id,jdbcType=BIGINT}"
    })
    int deleteByPrimaryKey(Long id);

    @Insert({
        "insert into passenger (id, member_id, ",
        "`name`, id_card, `type`, ",
        "create_time, update_time)",
        "values (#{id,jdbcType=BIGINT}, #{memberId,jdbcType=BIGINT}, ",
        "#{name,jdbcType=VARCHAR}, #{idCard,jdbcType=VARCHAR}, #{type,jdbcType=CHAR}, ",
        "#{createTime,jdbcType=TIMESTAMP}, #{updateTime,jdbcType=TIMESTAMP})"
    })
    int insert(Passenger record);

    int insertSelective(Passenger record);

    List<Passenger> selectByExample(PassengerExample example);

    @Select({
        "select",
        "id, member_id, `name`, id_card, `type`, create_time, update_time",
        "from passenger",
        "where id = #{id,jdbcType=BIGINT}"
    })
    @ResultMap("com.lx.train.member.mapper.PassengerMapper.BaseResultMap")
    Passenger selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") Passenger record, @Param("example") PassengerExample example);

    int updateByExample(@Param("record") Passenger record, @Param("example") PassengerExample example);

    int updateByPrimaryKeySelective(Passenger record);

    @Update({
        "update passenger",
        "set member_id = #{memberId,jdbcType=BIGINT},",
          "`name` = #{name,jdbcType=VARCHAR},",
          "id_card = #{idCard,jdbcType=VARCHAR},",
          "`type` = #{type,jdbcType=CHAR},",
          "create_time = #{createTime,jdbcType=TIMESTAMP},",
          "update_time = #{updateTime,jdbcType=TIMESTAMP}",
        "where id = #{id,jdbcType=BIGINT}"
    })
    int updateByPrimaryKey(Passenger record);
}