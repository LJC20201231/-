package com.lx.train.member.mapper;

import com.lx.train.member.domain.Ticket;
import com.lx.train.member.domain.TicketExample;
import java.util.List;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

public interface TicketMapper {
    long countByExample(TicketExample example);

    int deleteByExample(TicketExample example);

    @Delete({
        "delete from ticket",
        "where id = #{id,jdbcType=BIGINT}"
    })
    int deleteByPrimaryKey(Long id);

    @Insert({
        "insert into ticket (id, member_id, ",
        "passenger_id, passenger_name, ",
        "train_date, train_code, ",
        "carriage_index, seat_row, ",
        "seat_col, start_station, ",
        "start_time, end_station, ",
        "end_time, seat_type, create_time, ",
        "update_time)",
        "values (#{id,jdbcType=BIGINT}, #{memberId,jdbcType=BIGINT}, ",
        "#{passengerId,jdbcType=BIGINT}, #{passengerName,jdbcType=VARCHAR}, ",
        "#{trainDate,jdbcType=DATE}, #{trainCode,jdbcType=VARCHAR}, ",
        "#{carriageIndex,jdbcType=INTEGER}, #{seatRow,jdbcType=CHAR}, ",
        "#{seatCol,jdbcType=CHAR}, #{startStation,jdbcType=VARCHAR}, ",
        "#{startTime,jdbcType=TIME}, #{endStation,jdbcType=VARCHAR}, ",
        "#{endTime,jdbcType=TIME}, #{seatType,jdbcType=CHAR}, #{createTime,jdbcType=TIMESTAMP}, ",
        "#{updateTime,jdbcType=TIMESTAMP})"
    })
    int insert(Ticket record);

    int insertSelective(Ticket record);

    List<Ticket> selectByExample(TicketExample example);

    @Select({
        "select",
        "id, member_id, passenger_id, passenger_name, train_date, train_code, carriage_index, ",
        "seat_row, seat_col, start_station, start_time, end_station, end_time, seat_type, ",
        "create_time, update_time",
        "from ticket",
        "where id = #{id,jdbcType=BIGINT}"
    })
    @ResultMap("com.lx.train.member.mapper.TicketMapper.BaseResultMap")
    Ticket selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") Ticket record, @Param("example") TicketExample example);

    int updateByExample(@Param("record") Ticket record, @Param("example") TicketExample example);

    int updateByPrimaryKeySelective(Ticket record);

    @Update({
        "update ticket",
        "set member_id = #{memberId,jdbcType=BIGINT},",
          "passenger_id = #{passengerId,jdbcType=BIGINT},",
          "passenger_name = #{passengerName,jdbcType=VARCHAR},",
          "train_date = #{trainDate,jdbcType=DATE},",
          "train_code = #{trainCode,jdbcType=VARCHAR},",
          "carriage_index = #{carriageIndex,jdbcType=INTEGER},",
          "seat_row = #{seatRow,jdbcType=CHAR},",
          "seat_col = #{seatCol,jdbcType=CHAR},",
          "start_station = #{startStation,jdbcType=VARCHAR},",
          "start_time = #{startTime,jdbcType=TIME},",
          "end_station = #{endStation,jdbcType=VARCHAR},",
          "end_time = #{endTime,jdbcType=TIME},",
          "seat_type = #{seatType,jdbcType=CHAR},",
          "create_time = #{createTime,jdbcType=TIMESTAMP},",
          "update_time = #{updateTime,jdbcType=TIMESTAMP}",
        "where id = #{id,jdbcType=BIGINT}"
    })
    int updateByPrimaryKey(Ticket record);
}