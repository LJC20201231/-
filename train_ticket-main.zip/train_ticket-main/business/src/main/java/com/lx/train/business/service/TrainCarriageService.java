package com.lx.train.business.service;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.util.ObjectUtil;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.lx.train.business.domain.*;
import com.lx.train.business.enums.SeatColEnum;
import com.lx.train.common.exception.BusinessException;
import com.lx.train.common.exception.BusinessExceptionEnum;
import com.lx.train.common.resp.PageResp;
import com.lx.train.common.util.SnowUtil;
import com.lx.train.business.domain.TrainCarriageExample;
import com.lx.train.business.mapper.TrainCarriageMapper;
import com.lx.train.business.req.TrainCarriageQueryReq;
import com.lx.train.business.req.TrainCarriageSaveReq;
import com.lx.train.business.resp.TrainCarriageQueryResp;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;


@Slf4j
@Service
public class TrainCarriageService {
    @Autowired
    TrainCarriageMapper trainCarriageMapper;

    /**
     * 新增和编辑乘客操作
     * @param trainCarriageSaveReq
     */
    public void saveTrainCarriage(TrainCarriageSaveReq trainCarriageSaveReq) {
        DateTime now = DateTime.now();
        //自动计算列数和总座位数
        List<SeatColEnum> colsByType = SeatColEnum.getColsByType(trainCarriageSaveReq.getSeatType());
        trainCarriageSaveReq.setColCount(colsByType.size());
        trainCarriageSaveReq.setSeatCount(trainCarriageSaveReq.getColCount() * trainCarriageSaveReq.getRowCount());
        TrainCarriage trainCarriage = BeanUtil.toBean(trainCarriageSaveReq, TrainCarriage.class);
        if (trainCarriage.getId() == null) {
            //为空则完成新增操作
            //保存车厢前进行车厢独立性判断
            TrainCarriage trainCarriageDB = selectByUnique(trainCarriageSaveReq.getTrainCode(), trainCarriageSaveReq.getIndex());
            if (trainCarriageDB != null) {
                throw new BusinessException(BusinessExceptionEnum.BUSINESS_TRAIN_CARRIAGE_INDEX_UNIQUE_ERROR);
            }
            trainCarriage.setId(SnowUtil.getSnowflakeNextId());
            trainCarriage.setCreateTime(now);
            trainCarriage.setUpdateTime(now);
            trainCarriageMapper.insert(trainCarriage);
        }else {
            //不为空则完成编辑操作
            trainCarriage.setUpdateTime(now);
            trainCarriageMapper.updateByPrimaryKey(trainCarriage);
        }
    }

    private TrainCarriage selectByUnique(String TrainCode , int index) {
        TrainCarriageExample example = new TrainCarriageExample();
        example.createCriteria().andTrainCodeEqualTo(TrainCode).andIndexEqualTo(index);
        List<TrainCarriage> list = trainCarriageMapper.selectByExample(example);
        if (list != null && list.size() > 0) {
            return list.get(0);
        }else{
            return null;
        }
    }


    public PageResp<TrainCarriageQueryResp> queryList(TrainCarriageQueryReq req) {
        TrainCarriageExample trainCarriageExample = new TrainCarriageExample();
        trainCarriageExample.setOrderByClause("train_code asc, `index` asc");
        TrainCarriageExample.Criteria criteria = trainCarriageExample.createCriteria();
        if (req.getTrainCode() != null) {
            criteria.andTrainCodeEqualTo(req.getTrainCode());
        }
        log.info("查询页码：{}", req.getPage());
        log.info("每页条数：{}", req.getSize());
        PageHelper.startPage(req.getPage(), req.getSize());
        List<TrainCarriage> trainCarriageList = trainCarriageMapper.selectByExample(trainCarriageExample);

        PageInfo<TrainCarriage> pageInfo = new PageInfo<>(trainCarriageList);
        log.info("总行数：{}", pageInfo.getTotal());
        log.info("总页数：{}", pageInfo.getPages());

        List<TrainCarriageQueryResp> list = BeanUtil.copyToList(trainCarriageList, TrainCarriageQueryResp.class);

        PageResp<TrainCarriageQueryResp> pageResp = new PageResp<>();
        pageResp.setTotal(pageInfo.getTotal());
        pageResp.setList(list);
        return pageResp;
    }

    public void delete(Long id) {
        trainCarriageMapper.deleteByPrimaryKey(id);
    }

    public List<TrainCarriage> selectByTrainCode(String trainCode) {
        //根据火车编号获取车厢
        TrainCarriageExample trainCarriageExample = new TrainCarriageExample();
        TrainCarriageExample.Criteria criteria = trainCarriageExample.createCriteria();
        trainCarriageExample.setOrderByClause("`index` asc");
        criteria.andTrainCodeEqualTo(trainCode);
        List<TrainCarriage> trainCarriages = trainCarriageMapper.selectByExample(trainCarriageExample);
        return trainCarriages;
    }

    /**
     * 根据车次查询所有车厢
     * @param TrainCode
     * @return
     */
    public List<TrainCarriage> selectTrainCode(String TrainCode) {
        TrainCarriageExample example = new TrainCarriageExample();
        example.setOrderByClause("`index` asc");
        example.createCriteria().andTrainCodeEqualTo(TrainCode);
        List<TrainCarriage> list = trainCarriageMapper.selectByExample(example);
        return list;
    }

}
