package com.lx.train.business.controller.admin;


import com.lx.train.common.resp.CommonResp;
import com.lx.train.common.resp.PageResp;
import com.lx.train.business.req.ConfirmOrderQueryReq;
import com.lx.train.business.req.ConfirmOrderDoReq;
import com.lx.train.business.resp.ConfirmOrderQueryResp;
import com.lx.train.business.service.ConfirmOrderService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;

@RestController
@RequestMapping("/admin/confirm-order")
public class ConfirmOrderAdminController {
    @Autowired
    private ConfirmOrderService confirmOrderService;

     /**
      * 新增乘客接口
      * @param req
      * @return
      */
    @PostMapping("/save")
    public CommonResp<Object> save(@Valid @RequestBody ConfirmOrderDoReq req) {
        confirmOrderService.saveConfirmOrder(req);
        return new CommonResp<>();
    }

     /**
      * 乘客查询接口
      * @param req
      * @return
      */
     @GetMapping("/query-list")
     public CommonResp<PageResp<ConfirmOrderQueryResp>> queryList(@Valid ConfirmOrderQueryReq req) {
         PageResp<ConfirmOrderQueryResp> list = confirmOrderService.queryList(req);
         return new CommonResp<>(list);
     }

     @DeleteMapping("/delete/{id}")
     public CommonResp<Object> delete(@PathVariable Long id) {
         confirmOrderService.delete(id);
         return new CommonResp<>();
     }
}
