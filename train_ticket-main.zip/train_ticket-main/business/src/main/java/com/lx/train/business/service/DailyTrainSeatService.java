package com.lx.train.business.service;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.util.ObjUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.lx.train.business.domain.*;
import com.lx.train.common.resp.PageResp;
import com.lx.train.common.util.SnowUtil;
import com.lx.train.business.mapper.DailyTrainSeatMapper;
import com.lx.train.business.req.DailyTrainSeatQueryReq;
import com.lx.train.business.req.DailyTrainSeatSaveReq;
import com.lx.train.business.resp.DailyTrainSeatQueryResp;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;


@Slf4j
@Service
public class DailyTrainSeatService {
    @Autowired
    DailyTrainSeatMapper dailyTrainSeatMapper;
    @Autowired
    TrainSeatService trainSeatService;
    @Autowired
    TrainStationService trainStationService;
    /**
     * 新增和编辑操作
     * @param dailyTrainSeatSaveReq
     */
    public void saveDailyTrainSeat(DailyTrainSeatSaveReq dailyTrainSeatSaveReq) {
        DateTime now = DateTime.now();
        DailyTrainSeat dailyTrainSeat = BeanUtil.toBean(dailyTrainSeatSaveReq, DailyTrainSeat.class);
        if (dailyTrainSeat.getId() == null) {
            //为空则完成新增操作
            dailyTrainSeat.setId(SnowUtil.getSnowflakeNextId());
            dailyTrainSeat.setCreateTime(now);
            dailyTrainSeat.setUpdateTime(now);
            dailyTrainSeatMapper.insert(dailyTrainSeat);
        }else {
            //不为空则完成编辑操作
            dailyTrainSeat.setUpdateTime(now);
            dailyTrainSeatMapper.updateByPrimaryKey(dailyTrainSeat);
        }
    }

    /**
     * 查询操作
     * @param req
     */
    public PageResp<DailyTrainSeatQueryResp> queryList(DailyTrainSeatQueryReq req) {
        DailyTrainSeatExample dailyTrainSeatExample = new DailyTrainSeatExample();
        dailyTrainSeatExample.setOrderByClause("train_code asc, carriage_index asc, carriage_seat_index asc");
        DailyTrainSeatExample.Criteria criteria = dailyTrainSeatExample.createCriteria();
        if (ObjectUtil.isNotEmpty(req.getTrainCode())) {
            criteria.andTrainCodeEqualTo(req.getTrainCode());
        }
        log.info("查询页码：{}", req.getPage());
        log.info("每页条数：{}", req.getSize());
        PageHelper.startPage(req.getPage(), req.getSize());
        List<DailyTrainSeat> dailyTrainSeatList = dailyTrainSeatMapper.selectByExample(dailyTrainSeatExample);

        PageInfo<DailyTrainSeat> pageInfo = new PageInfo<>(dailyTrainSeatList);
        log.info("总行数：{}", pageInfo.getTotal());
        log.info("总页数：{}", pageInfo.getPages());

        List<DailyTrainSeatQueryResp> list = BeanUtil.copyToList(dailyTrainSeatList, DailyTrainSeatQueryResp.class);

        PageResp<DailyTrainSeatQueryResp> pageResp = new PageResp<>();
        pageResp.setTotal(pageInfo.getTotal());
        pageResp.setList(list);
        return pageResp;
    }

    /**
     * 删除操作
     * @param id
     */
    public void delete(Long id) {
        dailyTrainSeatMapper.deleteByPrimaryKey(id);
    }

    /**
     * 生成车次的每日车座
     * @param date
     * @param trainCode
     */
    public void genDaily(Date date , String trainCode){
        log.info("生成日期{} 车次{}的车座", date , trainCode);
        //先删除某日某车座车座信息
        DailyTrainSeatExample dailyTrainSeatExample = new DailyTrainSeatExample();
        dailyTrainSeatExample.createCriteria()
                .andDateEqualTo(date)
                .andTrainCodeEqualTo(trainCode);
        dailyTrainSeatMapper.deleteByExample(dailyTrainSeatExample);
        List<TrainStation> trainStations = trainStationService.selectTrainCode(trainCode);
        String sell = StrUtil.fillBefore("" , '0' , trainStations.size());

        //查出某车座所有信息
        List<TrainSeat> trainSeats = trainSeatService.selectTrainCode(trainCode);
        if (ObjUtil.isEmpty(trainSeats)) {
            log.info("该车次没有车座基础数据，生成该车次的车座信息结束");
            return;
        }
        for (TrainSeat trainSeat : trainSeats) {
            Date now = DateTime.now();
            DailyTrainSeat dailyTrainSeat = BeanUtil.copyProperties(trainSeat, DailyTrainSeat.class);
            dailyTrainSeat.setId(SnowUtil.getSnowflakeNextId());
            dailyTrainSeat.setCreateTime(now);
            dailyTrainSeat.setUpdateTime(now);
            dailyTrainSeat.setDate(date);
            dailyTrainSeat.setSell(sell);
            dailyTrainSeatMapper.insert(dailyTrainSeat);
        }
    }

    public int countSeat(String trainCode , Date date , String seatType){
        DailyTrainSeatExample dailyTrainSeatExample = new DailyTrainSeatExample();
        dailyTrainSeatExample.createCriteria().andTrainCodeEqualTo(trainCode)
                .andDateEqualTo(date)
                .andSeatTypeEqualTo(seatType);
        if (dailyTrainSeatMapper.countByExample(dailyTrainSeatExample) == 0L) {
            return -1;
        }
        return (int)dailyTrainSeatMapper.countByExample(dailyTrainSeatExample);
    }

    public List<DailyTrainSeat> selectByCarriage(Date date , String trainCode , Integer carriageIndex){
        DailyTrainSeatExample dailyTrainSeatExample = new DailyTrainSeatExample();
        dailyTrainSeatExample.setOrderByClause("carriage_seat_index asc");
        dailyTrainSeatExample.createCriteria().andDateEqualTo(date)
                .andTrainCodeEqualTo(trainCode)
                .andCarriageIndexEqualTo(carriageIndex);
        return dailyTrainSeatMapper.selectByExample(dailyTrainSeatExample);
    }


    public int countSeat(Date date, String trainCode) {
        return countSeat(date, trainCode, null);
    }

    public int countSeat(Date date, String trainCode, String seatType) {
        DailyTrainSeatExample example = new DailyTrainSeatExample();
        DailyTrainSeatExample.Criteria criteria = example.createCriteria();
        criteria.andDateEqualTo(date)
                .andTrainCodeEqualTo(trainCode);
        if (StrUtil.isNotBlank(seatType)) {
            criteria.andSeatTypeEqualTo(seatType);
        }
        long l = dailyTrainSeatMapper.countByExample(example);
        if (l == 0L) {
            return -1;
        }
        return (int) l;
    }
}
