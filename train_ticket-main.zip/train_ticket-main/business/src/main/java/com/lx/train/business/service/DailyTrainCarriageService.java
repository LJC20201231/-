package com.lx.train.business.service;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.util.ObjUtil;
import cn.hutool.core.util.ObjectUtil;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.lx.train.business.domain.*;
import com.lx.train.business.enums.SeatColEnum;
import com.lx.train.common.resp.PageResp;
import com.lx.train.common.util.SnowUtil;
import com.lx.train.business.mapper.DailyTrainCarriageMapper;
import com.lx.train.business.req.DailyTrainCarriageQueryReq;
import com.lx.train.business.req.DailyTrainCarriageSaveReq;
import com.lx.train.business.resp.DailyTrainCarriageQueryResp;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;


@Slf4j
@Service
public class DailyTrainCarriageService {
    @Autowired
    DailyTrainCarriageMapper dailyTrainCarriageMapper;
    @Autowired
    TrainCarriageService trainCarriageService;
    /**
     * 新增和编辑操作
     * @param dailyTrainCarriageSaveReq
     */
    public void saveDailyTrainCarriage(DailyTrainCarriageSaveReq dailyTrainCarriageSaveReq) {
        DateTime now = DateTime.now();
        List<SeatColEnum> colsByType = SeatColEnum.getColsByType(dailyTrainCarriageSaveReq.getSeatType());
        dailyTrainCarriageSaveReq.setColCount(colsByType.size());
        dailyTrainCarriageSaveReq.setSeatCount(colsByType.size() * dailyTrainCarriageSaveReq.getRowCount());
        DailyTrainCarriage dailyTrainCarriage = BeanUtil.toBean(dailyTrainCarriageSaveReq, DailyTrainCarriage.class);
        if (dailyTrainCarriage.getId() == null) {
            //为空则完成新增操作
            dailyTrainCarriage.setId(SnowUtil.getSnowflakeNextId());
            dailyTrainCarriage.setCreateTime(now);
            dailyTrainCarriage.setUpdateTime(now);
            dailyTrainCarriageMapper.insert(dailyTrainCarriage);
        }else {
            //不为空则完成编辑操作
            dailyTrainCarriage.setUpdateTime(now);
            dailyTrainCarriageMapper.updateByPrimaryKey(dailyTrainCarriage);
        }
    }

    /**
     * 查询操作
     * @param req
     */
    public PageResp<DailyTrainCarriageQueryResp> queryList(DailyTrainCarriageQueryReq req) {
        DailyTrainCarriageExample dailyTrainCarriageExample = new DailyTrainCarriageExample();
        DailyTrainCarriageExample.Criteria criteria = dailyTrainCarriageExample.createCriteria();
        if (ObjectUtil.isNotNull(req.getDate())) {
            criteria.andDateEqualTo(req.getDate());
        }
        if (ObjectUtil.isNotEmpty(req.getTrainCode())){
            criteria.andTrainCodeEqualTo(req.getTrainCode());
        }
        log.info("查询页码：{}", req.getPage());
        log.info("每页条数：{}", req.getSize());
        PageHelper.startPage(req.getPage(), req.getSize());
        List<DailyTrainCarriage> dailyTrainCarriageList = dailyTrainCarriageMapper.selectByExample(dailyTrainCarriageExample);

        PageInfo<DailyTrainCarriage> pageInfo = new PageInfo<>(dailyTrainCarriageList);
        log.info("总行数：{}", pageInfo.getTotal());
        log.info("总页数：{}", pageInfo.getPages());

        List<DailyTrainCarriageQueryResp> list = BeanUtil.copyToList(dailyTrainCarriageList, DailyTrainCarriageQueryResp.class);

        PageResp<DailyTrainCarriageQueryResp> pageResp = new PageResp<>();
        pageResp.setTotal(pageInfo.getTotal());
        pageResp.setList(list);
        return pageResp;
    }

    /**
     * 删除操作
     * @param id
     */
    public void delete(Long id) {
        dailyTrainCarriageMapper.deleteByPrimaryKey(id);
    }

    /**
     * 生成车次的每日车厢
     * @param date
     * @param trainCode
     */
    public void genDaily(Date date , String trainCode){
        log.info("生成日期{} 车次{}的车厢", date , trainCode);
        //先删除某日某车厢车厢信息
        DailyTrainCarriageExample dailyTrainCarriageExample = new DailyTrainCarriageExample();
        dailyTrainCarriageExample.createCriteria()
                .andDateEqualTo(date)
                .andTrainCodeEqualTo(trainCode);
        dailyTrainCarriageMapper.deleteByExample(dailyTrainCarriageExample);
        //查出某车厢所有信息
        List<TrainCarriage> trainCarriages = trainCarriageService.selectTrainCode(trainCode);
        if (ObjUtil.isEmpty(trainCarriages)) {
            log.info("该车次没有车厢基础数据，生成该车次的车厢信息结束");
            return;
        }
        for (TrainCarriage trainCarriage : trainCarriages) {
            Date now = DateTime.now();
            DailyTrainCarriage dailyTrainCarriage = BeanUtil.copyProperties(trainCarriage, DailyTrainCarriage.class);
            dailyTrainCarriage.setId(SnowUtil.getSnowflakeNextId());
            dailyTrainCarriage.setCreateTime(now);
            dailyTrainCarriage.setUpdateTime(now);
            dailyTrainCarriage.setDate(date);
            dailyTrainCarriageMapper.insert(dailyTrainCarriage);
        }
    }

    public List<DailyTrainCarriage> selectBySeatType(Date date , String trainCode , String seatType){
        DailyTrainCarriageExample dailyTrainCarriageExample = new DailyTrainCarriageExample();
        dailyTrainCarriageExample.createCriteria()
                                .andDateEqualTo(date)
                                .andTrainCodeEqualTo(trainCode).andSeatTypeEqualTo(seatType);
        return dailyTrainCarriageMapper.selectByExample(dailyTrainCarriageExample);

    }
}
