package com.lx.train.business.service;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.util.ObjectUtil;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.lx.train.business.domain.TrainCarriage;
import com.lx.train.business.domain.TrainCarriageExample;
import com.lx.train.common.exception.BusinessException;
import com.lx.train.common.exception.BusinessExceptionEnum;
import com.lx.train.common.resp.PageResp;
import com.lx.train.common.util.SnowUtil;
import com.lx.train.business.domain.TrainStation;
import com.lx.train.business.domain.TrainStationExample;
import com.lx.train.business.mapper.TrainStationMapper;
import com.lx.train.business.req.TrainStationQueryReq;
import com.lx.train.business.req.TrainStationSaveReq;
import com.lx.train.business.resp.TrainStationQueryResp;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;



@Slf4j
@Service
public class TrainStationService {
    @Autowired
    TrainStationMapper trainStationMapper;

    /**
     * 新增和编辑乘客操作
     * @param trainStationSaveReq
     */
    public void saveTrainStation(TrainStationSaveReq trainStationSaveReq) {
        DateTime now = DateTime.now();
        TrainStation trainStation = BeanUtil.toBean(trainStationSaveReq, TrainStation.class);
        if (trainStation.getId() == null) {
            //新增前完成唯一性判断
            TrainStation trainStationDB = selectByUnique(trainStationSaveReq.getTrainCode(), trainStationSaveReq.getIndex());
            if (trainStationDB != null) {
                throw new BusinessException(BusinessExceptionEnum.BUSINESS_TRAIN_STATION_INDEX_UNIQUE_ERROR);
            }
            trainStationDB = selectByUnique(trainStationSaveReq.getTrainCode(), trainStationSaveReq.getName());
            if (trainStationDB != null) {
                throw new BusinessException(BusinessExceptionEnum.BUSINESS_TRAIN_STATION_NAME_UNIQUE_ERROR);
            }
            //为空则完成新增操作
            trainStation.setId(SnowUtil.getSnowflakeNextId());
            trainStation.setCreateTime(now);
            trainStation.setUpdateTime(now);
            trainStationMapper.insert(trainStation);
        }else {
            //不为空则完成编辑操作
            trainStation.setUpdateTime(now);
            trainStationMapper.updateByPrimaryKey(trainStation);
        }
    }


    private TrainStation selectByUnique(String TrainCode , int index) {
        TrainStationExample example = new TrainStationExample();
        example.createCriteria().andTrainCodeEqualTo(TrainCode).andIndexEqualTo(index);
        List<TrainStation> list = trainStationMapper.selectByExample(example);
        if (list != null && list.size() > 0) {
            return list.get(0);
        }else{
            return null;
        }
    }
    private TrainStation selectByUnique(String TrainCode , String name) {
        TrainStationExample example = new TrainStationExample();
        example.createCriteria().andTrainCodeEqualTo(TrainCode).andNameEqualTo(name);
        List<TrainStation> list = trainStationMapper.selectByExample(example);
        if (list != null && list.size() > 0) {
            return list.get(0);
        }else{
            return null;
        }
    }
    /**
     *                          unique key `train_code_index_unique` (`train_code`, `index`),
     *                                  unique key `train_code_name_unique` (`train_code`, `name`)
     */

    public PageResp<TrainStationQueryResp> queryList(TrainStationQueryReq req) {
        TrainStationExample trainStationExample = new TrainStationExample();
        trainStationExample.setOrderByClause("train_code asc, `index` asc");
        TrainStationExample.Criteria criteria = trainStationExample.createCriteria();
        if (ObjectUtil.isNotEmpty(req.getTrainCode())) {
            criteria.andTrainCodeEqualTo(req.getTrainCode());
        }

        log.info("查询页码：{}", req.getPage());
        log.info("每页条数：{}", req.getSize());
        PageHelper.startPage(req.getPage(), req.getSize());
        List<TrainStation> trainStationList = trainStationMapper.selectByExample(trainStationExample);

        PageInfo<TrainStation> pageInfo = new PageInfo<>(trainStationList);
        log.info("总行数：{}", pageInfo.getTotal());
        log.info("总页数：{}", pageInfo.getPages());

        List<TrainStationQueryResp> list = BeanUtil.copyToList(trainStationList, TrainStationQueryResp.class);

        PageResp<TrainStationQueryResp> pageResp = new PageResp<>();
        pageResp.setTotal(pageInfo.getTotal());
        pageResp.setList(list);
        return pageResp;
    }



    public void delete(Long id) {
        trainStationMapper.deleteByPrimaryKey(id);
    }

    public List<TrainStation> selectTrainCode(String TrainCode) {
        TrainStationExample example = new TrainStationExample();
        example.setOrderByClause("`index` asc");
        example.createCriteria().andTrainCodeEqualTo(TrainCode);
        List<TrainStation> list = trainStationMapper.selectByExample(example);
        return list;
    }
}
