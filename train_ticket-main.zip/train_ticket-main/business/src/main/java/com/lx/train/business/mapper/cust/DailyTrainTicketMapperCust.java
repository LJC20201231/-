package com.lx.train.business.mapper.cust;

import com.lx.train.business.domain.DailyTrainTicket;
import org.apache.ibatis.annotations.Param;

import java.util.Date;

public interface DailyTrainTicketMapperCust {
    void updateCountBySell(
            @Param("date") Date date
            , @Param("trainCode") String trainCode
            , @Param("seatTypeCode") String seatTypeCode
            , @Param("minStartIndex") Integer minStartIndex
            , @Param("maxStartIndex") Integer maxStartIndex
            , @Param("minEndIndex") Integer minEndIndex
            , @Param("maxEndIndex") Integer maxEndIndex);
}
