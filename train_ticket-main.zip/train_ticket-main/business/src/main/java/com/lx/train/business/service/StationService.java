package com.lx.train.business.service;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.util.ObjectUtil;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.lx.train.business.domain.Train;
import com.lx.train.business.domain.TrainExample;
import com.lx.train.business.resp.TrainQueryResp;
import com.lx.train.common.exception.BusinessException;
import com.lx.train.common.exception.BusinessExceptionEnum;
import com.lx.train.common.resp.PageResp;
import com.lx.train.common.util.SnowUtil;
import com.lx.train.business.domain.Station;
import com.lx.train.business.domain.StationExample;
import com.lx.train.business.mapper.StationMapper;
import com.lx.train.business.req.StationQueryReq;
import com.lx.train.business.req.StationSaveReq;
import com.lx.train.business.resp.StationQueryResp;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Slf4j
@Service
public class StationService {
    @Autowired
    StationMapper stationMapper;


    public void saveStation(StationSaveReq stationSaveReq) {
        DateTime now = DateTime.now();
        Station station = BeanUtil.toBean(stationSaveReq, Station.class);
        if (station.getId() == null) {
            //保存之前，先校验唯一键是否存在
            Station stationDB = selectByUnique(stationSaveReq.getName());
            if (stationDB != null) {
                throw new BusinessException(BusinessExceptionEnum.BUSINESS_STATION_NAME_UNIQUE_ERROR);
            }
            //为空则完成新增操作
            station.setId(SnowUtil.getSnowflakeNextId());
            station.setCreateTime(now);
            station.setUpdateTime(now);
            stationMapper.insert(station);
        }else {
            //不为空则完成编辑操作
            station.setUpdateTime(now);
            stationMapper.updateByPrimaryKey(station);
        }
    }

    private Station selectByUnique(String name) {
        StationExample example = new StationExample();
        example.createCriteria().andNameEqualTo(name);
        List<Station> list = stationMapper.selectByExample(example);
        if (list != null && list.size() > 0) {
            return list.get(0);
        }else{
            return null;
        }
    }


    public PageResp<StationQueryResp> queryList(StationQueryReq req) {
        StationExample stationExample = new StationExample();
        StationExample.Criteria criteria = stationExample.createCriteria();

        log.info("查询页码：{}", req.getPage());
        log.info("每页条数：{}", req.getSize());
        PageHelper.startPage(req.getPage(), req.getSize());
        List<Station> stationList = stationMapper.selectByExample(stationExample);

        PageInfo<Station> pageInfo = new PageInfo<>(stationList);
        log.info("总行数：{}", pageInfo.getTotal());
        log.info("总页数：{}", pageInfo.getPages());

        List<StationQueryResp> list = BeanUtil.copyToList(stationList, StationQueryResp.class);

        PageResp<StationQueryResp> pageResp = new PageResp<>();
        pageResp.setTotal(pageInfo.getTotal());
        pageResp.setList(list);
        return pageResp;
    }


    public void delete(Long id) {
        stationMapper.deleteByPrimaryKey(id);
    }

    public List<StationQueryResp> queryAll() {
        StationExample stationExample = new StationExample();
        stationExample.setOrderByClause("name_pinyin asc");
        List<Station> stationList = stationMapper.selectByExample(stationExample);
        return BeanUtil.copyToList(stationList, StationQueryResp.class);
    }

}
