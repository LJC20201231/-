package com.lx.train.business.req;

import com.lx.train.common.req.PageReq;
import lombok.Data;
@Data
public class ConfirmOrderQueryReq extends PageReq {

}
