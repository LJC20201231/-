package com.lx.train.business.controller.admin;


import com.lx.train.common.resp.CommonResp;
import com.lx.train.common.resp.PageResp;
import com.lx.train.business.req.TrainCarriageQueryReq;
import com.lx.train.business.req.TrainCarriageSaveReq;
import com.lx.train.business.resp.TrainCarriageQueryResp;
import com.lx.train.business.service.TrainCarriageService;
import jakarta.annotation.Resource;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;

@RestController
@RequestMapping("/admin/train-carriage")
public class TrainCarriageAdminController {
    @Autowired
    private TrainCarriageService trainCarriageService;


    @PostMapping("/save")
    public CommonResp<Object> save(@Valid @RequestBody TrainCarriageSaveReq req) {
        trainCarriageService.saveTrainCarriage(req);
        return new CommonResp<>();
    }


     @GetMapping("/query-list")
     public CommonResp<PageResp<TrainCarriageQueryResp>> queryList(@Valid TrainCarriageQueryReq req) {
         PageResp<TrainCarriageQueryResp> list = trainCarriageService.queryList(req);
         return new CommonResp<>(list);
     }

     @DeleteMapping("/delete/{id}")
     public CommonResp<Object> delete(@PathVariable Long id) {
         trainCarriageService.delete(id);
         return new CommonResp<>();
     }
}
