package com.lx.train.business.controller.admin;


import com.lx.train.common.resp.CommonResp;
import com.lx.train.common.resp.PageResp;
import com.lx.train.business.req.SkTokenQueryReq;
import com.lx.train.business.req.SkTokenSaveReq;
import com.lx.train.business.resp.SkTokenQueryResp;
import com.lx.train.business.service.SkTokenService;
import jakarta.annotation.Resource;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;

@RestController
@RequestMapping("/admin/sk-token")
public class SkTokenAdminController {
    @Autowired
    private SkTokenService skTokenService;

     /**
      * 新增乘客接口
      * @param req
      * @return
      */
    @PostMapping("/save")
    public CommonResp<Object> save(@Valid @RequestBody SkTokenSaveReq req) {
        skTokenService.save(req);
        return new CommonResp<>();
    }

     /**
      * 乘客查询接口
      * @param req
      * @return
      */
     @GetMapping("/query-list")
     public CommonResp<PageResp<SkTokenQueryResp>> queryList(@Valid SkTokenQueryReq req) {
         PageResp<SkTokenQueryResp> list = skTokenService.queryList(req);
         return new CommonResp<>(list);
     }

     @DeleteMapping("/delete/{id}")
     public CommonResp<Object> delete(@PathVariable Long id) {
         skTokenService.delete(id);
         return new CommonResp<>();
     }
}
