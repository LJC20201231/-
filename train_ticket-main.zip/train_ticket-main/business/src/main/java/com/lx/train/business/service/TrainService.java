package com.lx.train.business.service;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.util.ObjectUtil;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.lx.train.business.domain.Station;
import com.lx.train.business.domain.StationExample;
import com.lx.train.common.exception.BusinessException;
import com.lx.train.common.exception.BusinessExceptionEnum;
import com.lx.train.common.resp.PageResp;
import com.lx.train.common.util.SnowUtil;
import com.lx.train.business.domain.Train;
import com.lx.train.business.domain.TrainExample;
import com.lx.train.business.mapper.TrainMapper;
import com.lx.train.business.req.TrainQueryReq;
import com.lx.train.business.req.TrainSaveReq;
import com.lx.train.business.resp.TrainQueryResp;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;


@Slf4j
@Service
public class TrainService {
    @Autowired
    TrainMapper trainMapper;

    /**
     * 新增火车操作
     * @param trainSaveReq
     */
    public void saveTrain(TrainSaveReq trainSaveReq) {
        DateTime now = DateTime.now();
        Train train = BeanUtil.toBean(trainSaveReq, Train.class);
        if (train.getId() == null) {
            //新增前完成独立性判断
            Train trainDB = selectByUnique(trainSaveReq.getCode());
            if (trainDB != null) {
                throw new BusinessException(BusinessExceptionEnum.BUSINESS_TRAIN_CODE_UNIQUE_ERROR);
            }
            //为空则完成新增操作
            train.setId(SnowUtil.getSnowflakeNextId());
            train.setCreateTime(now);
            train.setUpdateTime(now);
            trainMapper.insert(train);
        }else {
            //不为空则完成编辑操作
            train.setUpdateTime(now);
            trainMapper.updateByPrimaryKey(train);
        }
    }

    /**
     * 判断火车独立性
     * @param code
     * @return
     */
    private Train selectByUnique(String code) {
        TrainExample example = new TrainExample();
        example.createCriteria().andCodeEqualTo(code);
        List<Train> list = trainMapper.selectByExample(example);
        if (list != null && list.size() > 0) {
            return list.get(0);
        }else{
            return null;
        }
    }
    /**
     * 火车查询
     * @param req
     * @return
     */
    public PageResp<TrainQueryResp> queryList(TrainQueryReq req) {
        TrainExample trainExample = new TrainExample();
        TrainExample.Criteria criteria = trainExample.createCriteria();

        log.info("查询页码：{}", req.getPage());
        log.info("每页条数：{}", req.getSize());
        PageHelper.startPage(req.getPage(), req.getSize());
        List<Train> trainList = trainMapper.selectByExample(trainExample);

        PageInfo<Train> pageInfo = new PageInfo<>(trainList);
        log.info("总行数：{}", pageInfo.getTotal());
        log.info("总页数：{}", pageInfo.getPages());

        List<TrainQueryResp> list = BeanUtil.copyToList(trainList, TrainQueryResp.class);

        PageResp<TrainQueryResp> pageResp = new PageResp<>();
        pageResp.setTotal(pageInfo.getTotal());
        pageResp.setList(list);
        return pageResp;
    }

    public List<TrainQueryResp> queryAll() {
        List<Train> trainList = selectAll();
        return BeanUtil.copyToList(trainList, TrainQueryResp.class);
    }

    public List<Train> selectAll() {
        TrainExample trainExample = new TrainExample();
        trainExample.setOrderByClause("code desc");
        return trainMapper.selectByExample(trainExample);
    }


    public void delete(Long id) {
        trainMapper.deleteByPrimaryKey(id);
    }
}
