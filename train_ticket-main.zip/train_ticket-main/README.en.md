# Train Ticket Booking System

An online train ticket booking system based on a microservices architecture, built using the Spring Cloud technology stack.

## Project Overview

This project is a complete train ticket booking and management platform, offering core functionalities such as train queries, availability checks, order confirmation, and member management. The system adopts a microservices architecture with multiple independent service modules, supporting high-concurrency ticket processing scenarios.

## Technology Stack

- **Backend Framework**: Spring Boot, Spring Cloud  
- **Service Gateway**: Spring Cloud Gateway  
- **Service Registration & Configuration**: Nacos  
- **Database**: MyBatis, MySQL  
- **Cache**: Redis  
- **Message Queue**: RocketMQ  
- **Distributed Transaction**: Seata  
- **Traffic Control**: Sentinel  
- **Scheduled Tasks**: Quartz  
- **Remote Invocation**: Feign  

## Module Overview

### business (Business Service)
Core business module containing:
- Train Management (Train)
- Station Management (Station)
- Train Carriage Management (TrainCarriage)
- Seat Management (TrainSeat)
- Daily Train Schedule (DailyTrain)
- Daily Station (DailyTrainStation)
- Daily Seat (DailyTrainSeat)
- Daily Ticket (DailyTrainTicket)
- Order Confirmation (ConfirmOrder)
- Flash Sale Token (SkToken)

### member (Member Service)
Member management module providing:
- Member registration and login
- Passenger management
- Ticket inquiry

### batch (Scheduling Service)
Scheduled task service responsible for:
- Daily train data generation
- Scheduled task management

### gateway (Gateway Service)
API gateway providing:
- Unified routing
- Login interception
- JWT authentication

### common (Common Module)
Common components including:
- Unified response format
- Global exception handling
- JWT utility class
- Login context
- Log interceptor

### generator (Code Generator)
A code generation tool based on Freemarker for rapid generation of CRUD code.

## Core Business Flow

1. **Train Data Management**: Administrators maintain foundational data for trains, stations, carriages, and seats.
2. **Daily Schedule Generation**: The scheduling service automatically generates daily train operation schedules.
3. **Availability Inquiry**: Users query available tickets for a specific date and origin station.
4. **Flash Sale Tokens**: A token bucket mechanism controls traffic under high-concurrency scenarios.
5. **Order Confirmation**: Upon order submission, the system automatically assigns seats.
6. **Ticket Issuance**: A ticket is generated upon successful order confirmation.

## Quick Start

### Environment Requirements

- JDK 1.8+
- Maven 3.6+
- MySQL 5.7+
- Redis
- Nacos
- RocketMQ

### Configuration Files

Each module requires configuration of `bootstrap.properties` and `application.properties`. Key configurations include:

```properties
# Database configuration
spring.datasource.url=jdbc:mysql://localhost:3306/train
spring.datasource.username=root
spring.datasource.password=your_password

# Redis configuration
spring.redis.host=localhost
spring.redis.port=6379

# Nacos configuration
spring.cloud.nacos.discovery.server-addr=127.0.0.1:8848
spring.cloud.nacos.config.server-addr=127.0.0.1:8848
```

### Startup Sequence

1. Start the Nacos service registry
2. Start MySQL and execute SQL scripts (under `sql/` directory)
3. Start the Redis cache service
4. Start the RocketMQ message queue
5. Start each microservice module in sequence

### Build the Project

```bash
mvn clean package -DskipTests
```

## API Documentation

Main interfaces include:

### Station Management
- `GET /station/query-all` - Retrieve all station list

### Train Management
- `GET /train/query-all` - Retrieve all train list
- `POST /admin/train/save` - Save train information
- `GET /admin/train/gen-seat/{trainCode}` - Generate train seats

### Daily Train
- `GET /admin/daily-train/query-list` - Query daily train schedules
- `GET /admin/daily-train/gen-daily/{date}` - Generate train data for a specified date

### Ticket Inquiry
- `GET /daily-train-ticket/query-list` - Query available ticket information

### Order Confirmation
- `POST /confirm-order/do` - Submit order confirmation

### Member Management
- `POST /member/register` - Member registration
- `POST /member/send-code` - Send verification code
- `POST /member/login` - Member login

### Passenger Management
- `POST /passenger/save` - Save passenger information
- `GET /passenger/query-mine` - Query my passengers

## Project Structure

```
train_ticket/
├── batch/              # Scheduling Service
├── business/           # Core Business Service
├── common/             # Common Module
├── gateway/            # Gateway Service
├── generator/          # Code Generator
├── member/             # Member Service
├── sql/                # Database Scripts
└── test/               # API Test Files
```

## License

This project is for learning and communication purposes only.