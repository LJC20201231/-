package com.lx.train.batch.config;

import feign.Feign;
import feign.Contract;
import org.springframework.cloud.openfeign.support.SpringMvcContract;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
public class FeignConfig {

    @Primary
    @Bean
    public Contract feignContract() {
        return new SpringMvcContract();
    }

    @Primary
    @Bean
    public Feign.Builder feignBuilder(Contract contract) {
        return Feign.builder().contract(contract);
    }
}


