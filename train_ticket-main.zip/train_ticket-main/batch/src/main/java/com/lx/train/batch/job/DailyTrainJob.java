package com.lx.train.batch.job;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUnit;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.RandomUtil;
import com.lx.train.batch.feign.BusinessFeign;
import com.lx.train.common.resp.CommonResp;
import lombok.extern.slf4j.Slf4j;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;

@Slf4j
public class DailyTrainJob implements Job {
    @Autowired
    BusinessFeign businessFeign;
    @Override
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        //增加日志流水
        MDC.put("LOG_ID", System.currentTimeMillis() + RandomUtil.randomString(3));
        log.info("开始生成15日后的车次");
        Date date = new Date();
        DateTime dateTime = DateUtil.offsetDay(date, 15);
        Date jdkDate = dateTime.toJdkDate();
        CommonResp<Object> objectCommonResp = businessFeign.genDaily(jdkDate);
        log.info("生成15日后车次结束:{}", objectCommonResp);
    }
}
