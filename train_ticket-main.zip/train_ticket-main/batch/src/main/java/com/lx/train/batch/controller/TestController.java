package com.lx.train.batch.controller;

import com.lx.train.batch.feign.BusinessFeign;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
public class TestController {

    @Autowired
    BusinessFeign businessFeign;

    @GetMapping("/hello")
    public String hello() {
        log.info(businessFeign.hello());
        return "Hello World! " + businessFeign.hello();
    }
}
