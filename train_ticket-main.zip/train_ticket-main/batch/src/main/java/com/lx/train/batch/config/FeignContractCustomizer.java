package com.lx.train.batch.config;

import feign.Feign;
import org.springframework.cloud.openfeign.FeignBuilderCustomizer;
import org.springframework.cloud.openfeign.support.SpringMvcContract;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;

@Configuration
@Order(Ordered.LOWEST_PRECEDENCE)
public class FeignContractCustomizer implements FeignBuilderCustomizer {
    @Override
    public void customize(Feign.Builder builder) {
        builder.contract(new SpringMvcContract());
    }
}


